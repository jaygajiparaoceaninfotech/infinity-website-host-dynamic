<?php
// Include database connection
include 'connection.php';

// Check if ID is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Get the image path before deleting the record
    $query = $conn->prepare("SELECT image FROM about WHERE id=?");
    $query->bind_param("i", $id);
    $query->execute();
    $query->bind_result($imagePath);
    $query->fetch();
    $query->close();

    // Delete the record from the database
    $stmt = $conn->prepare("DELETE FROM about WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // If delete is successful
        if (file_exists($imagePath)) {
            // Unlink the image if it exists
            unlink($imagePath);
        }
        $message = "Record deleted successfully.";
        $status = "success";
    } else {
        // If delete fails
        $message = "Error: " . $stmt->error;
        $status = "error";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    $message = "No ID specified.";
    $status = "error";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete About Record</title>
    <!-- Include SweetAlert CSS and JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<script>
// Display SweetAlert based on PHP result
Swal.fire({
    title: "<?php echo $status == 'success' ? 'Success' : 'Error'; ?>",
    text: "<?php echo $message; ?>",
    icon: "<?php echo $status; ?>",
    showConfirmButton: false,  // Remove the OK button
    timer: 500  // Set the timer to 500 milliseconds
}).then(function() {
    // Redirect to the about-us page after the alert
    window.location.href = "about-us.php";
});
</script>

</body>
</html>
