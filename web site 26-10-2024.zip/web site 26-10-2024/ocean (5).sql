-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2024 at 09:07 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ocean`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `about_heading` varchar(255) DEFAULT NULL,
  `about_title` varchar(255) DEFAULT NULL,
  `about_description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `add_date` datetime DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `about_heading`, `about_title`, `about_description`, `image`, `add_date`, `modified_date`) VALUES
(1, ' Ocean Info Tech Solutions', 'Comprehensive IT Services', '\n<p>Oceaninfotech provides cutting-edge technology solutions designed to optimize business performance, enhance operational efficiency, and drive sustainable growth for a competitive edge in the digital landscape.</p>\n\n  <p class=\"text-dark\"><i class=\"fa fa-check text-primary me-3\"></i>We can save your money.</p>\n                        <p class=\"text-dark\"><i class=\"fa fa-check text-primary me-3\"></i>Production or trading of\n                            goods.</p>\n                        <p class=\"text-dark mb-4\"><i class=\"fa fa-check text-primary me-3\"></i>Our life insurance is\n                            flexible.</p>', 'uploads/about-1.png', '2024-10-24 16:36:34', '2024-10-26 12:01:35');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `username`, `email`, `password`, `state`) VALUES
(1, 'jaylo', 'admin', 'jaygajipara@gmaill.com', 'adsdsad', 'Assam'),
(2, 'jaylo', 'asdas', 'jaygajipara@gmaill.com', 'saddsa', 'Assam'),
(3, 'jayloasdas', 'asdas', 'ads@gmail.com', 'adsdas', 'Kerala'),
(4, 'jayu', 'asf', 'adasdasdsadass@gmail.com', 'asdasdasdsa', 'Gujarat'),
(5, 'Bhagds', 'ass', 'adds@gmail.com', 'sadsds', 'Assam'),
(6, 'John Doe', 'johndoe', 'johndoe@example.com', 'Password123', 'California'),
(7, 'Jane Smith', 'janesmith', 'janesmith@example.com', 'Password123', 'Texas'),
(8, 'Emily Johnson', 'emilyj', 'emilyj@example.com', 'Password123', 'Florida'),
(9, 'Michael Brown', 'michaelb', 'michaelb@example.com', 'Password123', 'New York'),
(10, 'Emma Davis', 'emmad', 'emmad@example.com', 'Password123', 'Illinois'),
(11, 'James Wilson', 'jamesw', 'jamesw@example.com', 'Password123', 'Ohio'),
(12, 'Olivia Martinez', 'oliviam', 'oliviam@example.com', 'Password123', 'Arizona'),
(13, 'William Garcia', 'williamg', 'williamg@example.com', 'Password123', 'Nevada'),
(14, 'Ava Rodriguez', 'avar', 'avar@example.com', 'Password123', 'Georgia'),
(15, 'Benjamin Lee', 'benjaminl', 'benjaminl@example.com', 'Password123', 'North Carolina'),
(16, 'Isabella Harris', 'isabellah', 'isabellah@example.com', 'Password123', 'Washington'),
(17, 'Sophia Clark', 'sophiac', 'sophiac@example.com', 'Password123', 'Virginia'),
(18, 'Elijah Lewis', 'elijahl', 'elijahl@example.com', 'Password123', 'Massachusetts'),
(19, 'Charlotte Hall', 'charlotteh', 'charlotteh@example.com', 'Password123', 'Pennsylvania'),
(20, 'Lucas Young', 'lucasy', 'lucasy@example.com', 'Password123', 'Tennessee'),
(21, 'Mia King', 'miak', 'miak@example.com', 'Password123', 'Minnesota'),
(22, 'Henry Wright', 'henryw', 'henryw@example.com', 'Password123', 'Colorado'),
(23, 'Amelia Scott', 'amelias', 'amelias@example.com', 'Password123', 'Oregon'),
(24, 'Oliver Green', 'oliverg', 'oliverg@example.com', 'Password123', 'Kentucky'),
(25, 'Aiden Adams', 'aidenad', 'aidenad@example.com', 'Password123', 'South Carolina'),
(26, 'Ella Baker', 'ellab', 'ellab@example.com', 'Password123', 'Alabama'),
(27, 'Jackson Gonzalez', 'jacksong', 'jacksong@example.com', 'Password123', 'Iowa'),
(28, 'Grace Nelson', 'gracen', 'gracen@example.com', 'Password123', 'Utah'),
(29, 'Sebastian Carter', 'sebastianc', 'sebastianc@example.com', 'Password123', 'Arkansas'),
(30, 'Zoe Mitchell', 'zoem', 'zoem@example.com', 'Password123', 'Connecticut'),
(31, 'Levi Perez', 'levip', 'levip@example.com', 'Password123', 'Missouri'),
(32, 'Chloe Roberts', 'chloer', 'chloer@example.com', 'Password123', 'Nevada'),
(33, 'Mason Turner', 'masont', 'masont@example.com', 'Password123', 'New Mexico'),
(34, 'Scarlett Phillips', 'scarlettp', 'scarlettp@example.com', 'Password123', 'Idaho'),
(35, 'Mateo Campbell', 'mateoc', 'mateoc@example.com', 'Password123', 'Hawaii'),
(36, 'Liam Parker', 'liamp', 'liamp@example.com', 'Password123', 'Maine'),
(37, 'Riley Edwards', 'rileye', 'rileye@example.com', 'Password123', 'Montana'),
(38, 'Luna Morris', 'lunam', 'lunam@example.com', 'Password123', 'South Dakota'),
(39, 'Jameson Murphy', 'jamesonm', 'jamesonm@example.com', 'Password123', 'North Dakota'),
(40, 'Bella Rivera', 'bellar', 'bellar@example.com', 'Password123', 'Vermont'),
(41, 'Isaac Cooper', 'isaacc', 'isaacc@example.com', 'Password123', 'Wyoming'),
(42, 'Victoria Reed', 'victoriar', 'victoriar@example.com', 'Password123', 'Alaska'),
(43, 'David Cox', 'davidc', 'davidc@example.com', 'Password123', 'Delaware'),
(44, 'Sofia Richardson', 'sofiar', 'sofiar@example.com', 'Password123', 'Rhode Island'),
(45, 'Gavin Hayes', 'gavin', 'gavin@example.com', 'Password123', 'New Hampshire'),
(46, 'Arianna Turner', 'ariannat', 'ariannat@example.com', 'Password123', 'West Virginia'),
(47, 'Caleb Foster', 'calebf', 'calebf@example.com', 'Password123', 'Nebraska'),
(48, 'Autumn Simmons', 'autumns', 'autumns@example.com', 'Password123', 'Mississippi'),
(49, 'Jaxon Barnes', 'jaxonb', 'jaxonb@example.com', 'Password123', 'Kansas'),
(50, 'Aria Wood', 'ariaw', 'ariaw@example.com', 'Password123', 'Louisiana'),
(51, 'Isaiah Bennett', 'isaiahb', 'isaiahb@example.com', 'Password123', 'Oklahoma'),
(52, 'Cameron Hughes', 'cameronh', 'cameronh@example.com', 'Password123', 'Tennessee'),
(53, 'Sadie Ward', 'sadiew', 'sadiew@example.com', 'Password123', 'Maryland');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `passwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `passwd`) VALUES
(1, 'admin', 'admin'),
(2, 'jay', 'jay');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `service_heading` varchar(255) NOT NULL,
  `service_title` varchar(255) NOT NULL,
  `service_description` text NOT NULL,
  `add_date` datetime DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `service_heading`, `service_title`, `service_description`, `add_date`, `modified_date`, `image`) VALUES
(1, 'asd', 'ad', '', '2024-10-25 11:01:13', '2024-10-25 11:01:13', 'uploads/instagram-footer-2.jpg'),
(2, 'qweeq', 'qeqweqwe', '', '2024-10-25 11:06:27', '2024-10-25 11:06:27', 'uploads/instagram-footer-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `modified_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `icon`, `image`, `link`, `modified_date`) VALUES
(1, 'Jayu', '<p><strong>Protection against financial loss risk.</strong></p>\n', 'fa-users ', 'uploads/blog-1.png', 'LifeInsurance.php', '2024-10-26 12:27:40'),
(2, 'Health Insurance', '<p>Coverage for medical expenses incurred.</p>\r\n', 'fa-hospital', 'uploads/blog-2.png', 'HealthInsurance.php', '2024-10-26 10:22:00'),
(3, 'Car Insurance', '<p>Financial protection for vehicle damages.</p>\r\n', 'fa-car', 'uploads/blog-3.png', 'CarInsurance.php', '2024-10-26 10:29:10'),
(4, 'Home Insurance', '<p>Protection against property damage losses.</p>\r\n', 'fa-home', 'uploads/blog-4.png', 'HomeInsurance.php', '2024-10-26 10:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `slider_heading` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `add_date` datetime DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `slider_heading`, `title`, `description`, `image`, `add_date`, `modified_date`) VALUES
(1, 'Welcome To Oceaninfotech', 'Innovating Tomorrow’s Tech Solutions', '<p><strong>We believe that in today&rsquo;s world, to succeed, you must be seen and get connected with the right people</strong></p>', 'uploads/carousel-2.png', '2024-10-24 11:52:53', '2024-10-26 11:30:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
