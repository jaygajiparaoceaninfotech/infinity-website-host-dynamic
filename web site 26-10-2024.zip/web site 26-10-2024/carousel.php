<?php
// Database connection
// Database connection
include 'connection.php';

// SQL query to fetch all slider details
$sql = "SELECT slider_heading, title, description, image FROM slider"; // Corrected the column name
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    // Fetch the data
    while ($row = $result->fetch_assoc()) {
        $slider_heading= $row['slider_heading']; // Make sure this variable is defined
        $title = $row['title'];
        $description = $row['description'];
        $image = $row['image'];
    }
} 

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carousel </title>

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <!-- Owl Carousel CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" rel="stylesheet">

    <!-- Custom CSS (if needed) -->
    <style>
        .calrousel-img {
            /* Adjust styles as needed */
        }
    </style>
</head>

<body>
    <div class="header-carousel owl-carousel">
        <div class="header-carousel-item"
            style="background-color: rgba(249, 162, 14, 0.68); color: rgba(0, 0, 0, 0.2);">

            <div class="carousel-caption">
                <div class="container">
                    <div class="row g-4 align-items-center">
                        <div class="col-lg-7 animated fadeInLeft">
                            <div class="text-sm-center text-md-start">
                            <h4 class="text-white text-uppercase fw-bold mb-4"><?php echo @$slider_heading; ?></h4>
                            <h1 class="display-1 text-white mb-4"><?php echo @$title; ?></h1>
                            <p class="mb-5 fs-5"><?php echo @$description; ?></p>
                            </div>
                        </div>
                        <div class="col-lg-5 animated fadeInRight">
                            <div class="calrousel-img" style="object-fit: cover;">
                            <img src="admin/<?php echo $image; ?>" class="img-fluid w-100" alt="">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-carousel-item"
            style="background-color: rgba(249, 162, 14, 0.68); color: rgba(0, 0, 0, 0.2);">

            <div class="carousel-caption">
                <div class="container">
                    <div class="row gy-4 gy-lg-0 gx-0 gx-lg-5 align-items-center">
                        <div class="col-lg-5 animated fadeInLeft">
                            <div class="calrousel-img">
                            <img src="admin/<?php echo $image; ?>" class="img-fluid w-100" alt="">  
                            </div>
                        </div>
                        <div class="col-lg-7 animated fadeInRight">
                            <div class="text-sm-center text-md-end">
                            <h4 class="text-white text-uppercase fw-bold mb-4"><?php echo @$slider_heading; ?></h4>
                            <h1 class="display-1 text-white mb-4"><?php echo @$title; ?></h1>
                            <p class="mb-5 fs-5"><?php echo @$description; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

    <!-- Custom JS (if needed) -->
    <script>
        $(document).ready(function () {
            $('.header-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,  
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                items: 1,
            });
        });
    </script>
</body>

</html>
