<div class="container-fluid copyright py-4">
    <div class="container">
        <div class="row g-4 align-items-center">
            <!-- Left Side: Copyright Text -->
            <div class="col-md-6 text-center text-md-start mb-md-0">
                <span class="text-body">
                    <a href="https://www.oceaninfotech.co.in/">
                        <i class="fas fa-copyright text-light me-2"></i>OceanInfotech
                    </a>, <span style="color: #ffffff;">All rights reserved.</span>
                </span>
            </div>
            <div class="col-md-6 text-center text-md-end text-body">
                <span style="color: #ffffff;">Designed By</span>
                <a href="http://www.oceaninfotech.co.in/">
                    Ocean Infotech
                </a>
            </div>
        </div>
    </div>
</div>
