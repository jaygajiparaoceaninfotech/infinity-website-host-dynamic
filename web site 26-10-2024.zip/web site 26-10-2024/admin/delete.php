<?php
// Include database connection
include 'connection.php';

// Check if ID is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare and execute delete statement
    $stmt = $conn->prepare("DELETE FROM slider WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Record deleted successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Redirect to the table page
    header('Location: table.php');
    exit();
} else {
    echo "No ID specified.";
    exit();
}
?>
