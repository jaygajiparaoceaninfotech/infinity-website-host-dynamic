<div class="logo-header ps-5" data-background-color="dark" style="height: 80px; width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 0 20px; background-color: #333;">
    <a href="index.php" class="logo">
        <img src="https://www.oceaninfotech.co.in/assets/images/logo-1.png" alt="navbar brand" style="height: 60px; width: auto;">
    </a>
    <div class="nav-toggle" style="display: flex; gap: 10px;">
        <button class="btn btn-toggle toggle-sidebar" style="height: 40px; width: 40px; background-color: transparent; border: none; cursor: pointer; color: white;">
            <i class="gg-menu-right"></i>
        </button>
        <button class="btn btn-toggle sidenav-toggler" style="height: 40px; width: 40px; background-color: transparent; border: none; cursor: pointer; color: white;">
            <i class="gg-menu-left"></i>
        </button>
    </div>
    <button class="topbar-toggler more" style="background-color: transparent; border: none; cursor: pointer;">
        <i class="gg-more-vertical-alt"></i>
    </button>
</div>