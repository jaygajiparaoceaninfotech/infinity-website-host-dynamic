<?php
include('connection.php');
session_start();

if (isset($_POST['submit'])) {
    $usrname = $_POST['usrname'];
    $password = $_POST['pswd'];

    // Prepared statement to prevent SQL injection and enforce case-sensitive password check
    $sql = "SELECT * FROM login WHERE BINARY  username=? AND BINARY passwd=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $usrname, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_array($result);

    // Check for valid user credentials
    if ($data) {
        $_SESSION['username'] = $usrname;
        $success_message = "Login successful! Redirecting to the dashboard...";
        // You can redirect to dashboard here, e.g.:
        // header("Location: dashboard.php");
        // exit();
    } else {
        // Check for case sensitivity and provide relevant messages
        if (!empty($usrname) && !empty($password)) {
            // Check if username exists to inform user
            $check_username = "SELECT * FROM login WHERE username=?";
            $stmt_check = mysqli_prepare($conn, $check_username);
            mysqli_stmt_bind_param($stmt_check, "s", $usrname);
            mysqli_stmt_execute($stmt_check);
            $result_check = mysqli_stmt_get_result($stmt_check);
            $user_exists = mysqli_fetch_array($result_check);

            if ($user_exists) {
                // Username exists but password does not match
                $error_message = "Incorrect password. Please try again.";
            } else {
                // Username does not exist
                $error_message = "Invalid username or password.";
            }
        } else {
            $error_message = "Please enter both username and password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Log In Admin Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .login-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .card-body img {
            max-width: 100%;
            height: 50px;
            object-fit: contain;
        }

        /* Media queries for responsiveness */
        @media (max-width: 768px) {
            .login-container {
                padding: 20px;
            }

            .card-body img {
                height: 40px; /* Adjust logo size for smaller screens */
            }
        }

        @media (max-width: 576px) {
            .login-container {
                padding: 15px;
            }

            .card-body img {
                height: 35px;
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid vh-100 d-flex justify-content-center align-items-center">
        <div class="login-container">
            <div class="card shadow w-100">
                <div class="card-body text-center">
                    <img src="https://www.oceaninfotech.co.in/assets/images/ring.png" alt="Logo" class="img-fluid mb-3">
                    <h4 class="card-title text-dark">Administrative Login</h4>

                    <form method="post" class="d-flex flex-column align-items-center">
                        <div class="form-group w-100">
                            <input type="text" class="form-control" placeholder="Username" name="usrname" required>
                        </div>
                        <div class="form-group w-100">
                            <input type="password" class="form-control" name="pswd" placeholder="Password" required>
                        </div>
                        <div class="text-center w-100">
                            <button type="submit" name="submit" class="btn btn-dark btn-block">SIGN IN</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if (isset($error_message)): ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?= $error_message; ?>',
            });
        <?php elseif (isset($success_message)): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?= $success_message; ?>',
                timer: 1000,
                showConfirmButton: false,
            }).then(function () {
                window.location.href = "index.php";
            });
        <?php endif; ?>
    </script>
</body>

</html>
