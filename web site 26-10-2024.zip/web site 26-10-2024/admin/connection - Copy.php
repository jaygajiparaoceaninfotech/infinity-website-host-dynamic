<?php
$servername = "sql100.infinityfree.com";
$username = "if0_37565283";
$password = "4PIaKtt6ZoyRJH";
$database='if0_37565283_ocean';

// Create connection
$conn = mysqli_connect($servername, $username, $password,$database);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

?>