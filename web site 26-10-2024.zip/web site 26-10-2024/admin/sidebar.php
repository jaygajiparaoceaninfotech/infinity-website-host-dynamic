<div class="sidebar" data-background-color="dark">
    <div class="sidebar-logo">
        <!-- Logo Header -->
        <?php include 'header.php'; ?>
        <!-- End Logo Header -->
    </div>
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <ul class="nav nav-secondary">
                <li class="nav-item <?= ($current_page == 'index.php') ? 'active' : '' ?>">
                    <a href="index.php">
                        <i class="fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item <?= ($current_page == 'forms.php') ? 'active' : '' ?>">
                    <a href="forms.php">
                        <i class="fas fa-pen-square"></i>
                        <p>Forms</p>
                    </a>
                </li>

                <li class="nav-item <?= ($current_page == 'datatables.php') ? 'active' : '' ?>">
                    <a href="datatables.php">
                        <i class="fas fa-table"></i>
                        <p>Datatables</p>
                    </a>
                </li>
                <li class="nav-item <?= ($current_page == 'slider.php') ? 'active' : '' ?>">
                    <a href="slider.php">
                        <i class="fa-solid fa-sliders"></i>
                        <p>Slider</p>
                    </a>
                </li>
                <li class="nav-item <?= ($current_page == 'services.php') ? 'active' : '' ?>">
                    <a href="services.php">
                        <i class="fa-solid fa-briefcase"></i>
                        <p>Services</p>
                    </a>
                </li>
                <li class="nav-item <?= ($current_page == 'about-us.php') ? 'active' : '' ?>">
                    <a href="about-us.php">
                        <i class="fas fa-info"></i>
                        <p>About us</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
