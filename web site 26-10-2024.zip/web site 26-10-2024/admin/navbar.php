<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logout Confirmation</title>
  <!-- SweetAlert CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
  <!-- SweetAlert JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
  <nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">
    <div class="container-fluid">
      <ul class="navbar-nav topbar-nav ms-md-auto align-items-center bg-light text-dark">
        <li class="nav-item topbar-user dropdown">
          <a href="#" class="profile-pic d-flex align-items-center dropdown-toggle" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="avatar-sm">
              <img src="assets/img/profile.jpg" alt="Profile Picture" class="avatar-img rounded-circle" />
            </div>
            <span class="profile-username ms-2">
              <span class="op-7">Hi,</span>
              <span class="fw-bold"><?php echo $username; ?></span> <!-- Dynamic username -->
            </span>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="myprofile.php">My Profile</a>
            <a class="dropdown-item text-danger" href="#" onclick="confirmLogout(event)">Logout</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>

  <script>
    function confirmLogout(event) {
      event.preventDefault(); // Prevent the default anchor click behavior
      swal({
        title: "Are you sure?",
        text: "You will be logged out!",
        icon: "warning",
        buttons: {
          cancel: "No, cancel!",
          confirm: {
            text: "Yes, logout!",
            value: true,
            visible: true,
            className: "btn-danger"
          }
        },
        dangerMode: true,
      }).then((willLogout) => {
        if (willLogout) {
          // Redirect to logout.php
          window.location.href = "logout.php";
        }
      });
    }
  </script>

  <!-- Bootstrap JS (make sure to include jQuery first) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
